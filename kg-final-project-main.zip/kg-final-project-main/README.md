![alt text](https://github.com/daphnen7777/kg-final-project/blob/main/Final-Project/3팀_aws_gcp_3tier.png?raw=true)
terraform version
get credential file from google
